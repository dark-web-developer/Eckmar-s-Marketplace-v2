@extends('includes.purchases.purchase')

@section('purchase-title', 'Purchase - #' . $purchase -> short_id)