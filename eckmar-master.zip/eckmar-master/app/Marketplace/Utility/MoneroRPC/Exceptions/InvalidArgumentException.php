<?php


namespace App\Marketplace\Utility\MoneroRPC\Exceptions;


class InvalidArgumentException extends \Exception
{

}